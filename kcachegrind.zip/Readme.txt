Building kcachegrind (http://kcachegrind.sourceforge.net/html/Home.html) on windows at this point is pretty time consuming. 
I created this package to make life easier if you just want to try it out on windows. (kcachegrind :LGPL, QT: LGPL, dot: CPL)

The original source code is from:

kcachegrind.exe:
http://kcachegrind.sourceforge.net/html/Home.html

dot.exe:
http://www.graphviz.org/

The binaries are built using QT 4.7 LGPL 
http://qt.nokia.com/products/

